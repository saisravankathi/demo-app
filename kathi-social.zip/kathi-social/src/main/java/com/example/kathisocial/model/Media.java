package com.example.kathisocial.model;

import com.fasterxml.jackson.annotation.JsonSetter;

import javax.persistence.*;
import java.io.UnsupportedEncodingException;
import java.util.Base64;

@Entity
public class Media {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "media")
    @Lob
    private byte[] media;

    @Column(name = "name")
    private String name;

    public Media() {
    }

    public Media(String name,  byte[] media) {
        this.name = name;
        this.media = media;

    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public byte[] getMedia() {
        return media;
    }

    public void setMedia(byte[] media) {
        this.media = media;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
