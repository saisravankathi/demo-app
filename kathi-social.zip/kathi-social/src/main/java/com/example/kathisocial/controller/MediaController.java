package com.example.kathisocial.controller;

import com.example.kathisocial.model.Media;
import com.example.kathisocial.model.Post;
import com.example.kathisocial.repository.MediaRepository;
import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.zip.DataFormatException;
import java.util.zip.Deflater;
import java.util.zip.Inflater;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class MediaController {
        @Autowired
        MediaRepository mediaRepository;
        @PostMapping("/upload")
        public Media uplaodImage(@RequestParam("imageFile") MultipartFile file) throws IOException {
            System.out.println("Original Image Byte Size - " + file.getBytes().length);
            Media img = new Media(file.getOriginalFilename(),
                    file.getBytes());
            System.out.println("this is retrived" + file.getBytes().length);
            return mediaRepository.save(img);
        }

    @GetMapping("/latest-image")
    public Media getLatestImage(){
        return mediaRepository.findAll(Sort.by(Sort.Direction.DESC, "id")).get(0);
    }


    public static byte[] compressBytes(byte[] data) {
        Deflater deflater = new Deflater();
        deflater.setInput(data);
        deflater.finish();
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream(data.length);
        byte[] buffer = new byte[1024];
        while (!deflater.finished()) {
            int count = deflater.deflate(buffer);
            outputStream.write(buffer, 0, count);
        }
        try {
            outputStream.close();
        } catch (IOException e) {
        }
        System.out.println("Compressed Image Byte Size - " + outputStream.toByteArray().length);
        return outputStream.toByteArray();
    }


}
