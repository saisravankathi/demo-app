package com.example.kathisocial.controller;

import com.example.kathisocial.data.PostData;
import com.example.kathisocial.model.Media;
import com.example.kathisocial.model.Post;
import com.example.kathisocial.repository.MediaRepository;
import com.example.kathisocial.repository.PostRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.zip.DataFormatException;
import java.util.zip.Deflater;
import java.util.zip.Inflater;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class PostController {

    @Autowired
    private PostRepository repository;

    @Autowired
    private MediaRepository mediaRepository;

    @GetMapping("/posts")
    public List<Post> getAllPosts(){
        return repository.findAll(Sort.by(Sort.Direction.DESC, "id"));
    }

    @PostMapping("/posts")
    public Post createPost(@RequestBody Post post){
        if(null != post.getMediaId()) {
            Optional<Media> media = mediaRepository.findById(post.getMediaId());
            System.out.println("this is the saved image in post" + media.get().getMedia().length);
            post.setMedia(media.get().getMedia());
            Post mediaPost = repository.save(post);
            return mediaPost;

        }
        Post createdPost = repository.save(post);
        return createdPost;
    }

    @PutMapping("posts/{postId}")
    public Post updatePost(@RequestBody Post post, @PathVariable Long postId){
        return repository.findById(postId).map(optionalPost -> {
            optionalPost.setContent(post.getContent());
            optionalPost.setTitle(post.getTitle());
            if(null != post.getMediaId()) {
                Optional<Media> media = mediaRepository.findById(post.getMediaId());
                optionalPost.setMedia(media.get().getMedia());
            }
            return repository.save(optionalPost);
        }).orElseThrow(() -> new RuntimeException("PostId " + postId + " not found"));
    }

    @DeleteMapping("posts/{postId}")
    public ResponseEntity<?> deleteMapping(@PathVariable Long postId){
        //TODO, delting the media by fetching Media from media repository is not done yet, which is delete the abandoned media, ideal way is to establish a relationship.
        return repository.findById(postId).map(optionalPost -> {
            repository.delete(optionalPost);
            return ResponseEntity.ok().build();
        }).orElseThrow(() -> new RuntimeException("PostId " + postId + " not found"));
    }

    public static byte[] decompressBytes(byte[] data) {
        Inflater inflater = new Inflater();
        inflater.setInput(data);
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream(data.length);
        byte[] buffer = new byte[1024];
        try {
            while (!inflater.finished()) {
                int count = inflater.inflate(buffer);
                outputStream.write(buffer, 0, count);
            }
            outputStream.close();
        } catch (IOException ioe) {
        } catch (DataFormatException e) {
        }
        return outputStream.toByteArray();
    }
}
