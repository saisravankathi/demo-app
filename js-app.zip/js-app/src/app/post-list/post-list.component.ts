import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Post } from '../model/post';
import { PostService } from '../post-service/post.service';

@Component({
  selector: 'app-post-list',
  templateUrl: './post-list.component.html',
  styleUrls: ['./post-list.component.css']
})
export class PostListComponent implements OnInit {

  posts$: Observable<Post[]>;
  posts: Post[];
  formData: FormGroup;
  newPost: Post;
  selectedFile: File;
  postId: number;
  view: boolean = false;

  constructor(private postService: PostService, private router: Router) { }

  ngOnInit(): void {
    this.formData = new FormGroup({
      title: new FormControl(""),
      content: new FormControl("")
    });

    // this.posts$ = this.postService.getAllPosts();
    this.postService.getAllPosts().subscribe(data => {
      data.forEach(d => {
        if (d.media !== undefined || d.media !== null) {
          d.mediaurl = 'data:image/png;base64,' + d.media;
        }
      });
      console.log(data);
      this.posts = data;
    })
  }

  public onClickSubmit() {
    const data = this.formData.value;
    if (this.postId !== undefined) {
      this.newPost = {
        id: this.postId,
        content: data.content,
        title: data.title
      }
    } else {
      this.newPost = {
        content: data.content,
        title: data.title
      }
    }
    const uploadImageData = new FormData();
    if (this.selectedFile !== undefined) {
      console.log(data, 'data');
      uploadImageData.append('title', data.title);
      uploadImageData.append('imageFile', this.selectedFile, this.selectedFile.name);
      const mediaData = this.postService.uploadImage(uploadImageData, this.newPost, this.view);
      if (this.view) {
        this.view = false;
      }
    } else {
      // console.log("printing view value", this.view);
      if (this.view) {
        console.log("printing view value", this.newPost);
        this.postService.updateData(this.newPost);
        this.view = false;
      } else {
        const kathi = this.postService.createPost(this.newPost);
      }
    }
    // console.log('entered submit', this.newPost);

    // const kathi  = this.postService.createPost(this.newPost);
    // console.log('after submit', kathi);
    setTimeout(() => {
      console.log('waiting');
      window.location.reload();
    },
      3000);
  }

  public deletePost(data) {
    // console.log(data);
    this.postService.deletePost(data.id);
    window.location.reload();
  }

  public viewPost(data) {
    //TODO 
    //  console.log(data);
    this.postId = data.id;
    this.view = true;
    this.formData = new FormGroup({
      title: new FormControl(data.title),
      content: new FormControl(data.content)
    });
  }

  public onFileChanged(event) {
    //Select File
    this.selectedFile = event.target.files[0];

  }

}
