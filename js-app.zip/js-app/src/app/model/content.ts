export class Content {
    id: number;
    textContent: string;
    post: string;
}