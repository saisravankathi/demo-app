export class Post{
    id?: number;
    title: string;
    content: string;
    media?: any;
    mediaId?: number;
    mediaurl?: any;
}