import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Post } from '../model/post';

@Injectable({
  providedIn: 'root'
})
export class PostService {
  
  private allPostsUrl: string;
  private createPostUrl: string;
  post: Post;
  private postId: number;

  constructor(private http:HttpClient) { 
    this.allPostsUrl = "http://localhost:8080/posts";
    this.createPostUrl = "http://localhost:8080/posts";
  }

  public getAllPosts(): Observable<Post[]> {
    return this.http.get<Post[]>(this.allPostsUrl);
  }

  public createPost(postValue: Post): Post{
    // console.log('entered post', post);
    this.http.post<Post>(this.createPostUrl, postValue).subscribe(data => {
      this.post = {
        id: data.id,
        title: data.title,
        content: data.content 
      };
      this.postId = data.id;
    });
    console.log("post value is: ", this.postId);
    return this.post;
  }

  public deletePost(postId) {
    // console.log('entered delete');
    const deletePostUrl = `http://localhost:8080/posts/${postId}`;

    this.http.delete(deletePostUrl).subscribe(data => {
      console.log(data);
    });
  }

  public uploadImage(imageData: FormData, postRequest: Post, view: boolean){
    const uploadImageUrl = 'http://localhost:8080/upload';
    
    this.http.post('http://localhost:8080/upload', imageData, { observe: 'response' })
      .subscribe((response) => {
        if (response.status === 200) {
          // console.log('response', response);
          this.post = {
            id: postRequest.id,
            title: postRequest.title,
            content: postRequest.content,
            mediaId: response.body['id'] 
          };
          console.log(response.body['id'], this.post, " test these values");
          if(view){
            this.updateData(this.post)
          }else{
          this.createPost(this.post);
          }
        } else {
          return "Image not uploaded successfully";
        }
      }
      );
  }

  public updateData(newPost: Post) {
    const updateUrl = `http://localhost:8080/posts/${newPost.id}`;
    return this.http.put<Post>(updateUrl, newPost).subscribe(data =>{
      console.log('output put recieved');
    });
  }
}
